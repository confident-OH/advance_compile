

/* Your test program. */
void main() {
    long i;
    i = 0;
    while (i < 10) {
        i = i + 1;
    }
}