#include <iostream>
#include <bits/stdc++.h>

#include "../include/program.h"
using namespace std;


int main(){
    Program prog(cin);
    cout<<prog;
    //printcfg(cout,prog);
    //printscr(cout,prog);
    return 0;
}
