#ifndef __INCLUDE_H__
#define __INCLUDE_H__

#include <string>
#include <vector>
#include <map>
#include <assert.h>
#include <unordered_map>
#include <bits/stdc++.h>

using namespace std;

#define SIZE 8

#define GlobalArraySize = (32768/SIZE)

#define null NULL


#endif