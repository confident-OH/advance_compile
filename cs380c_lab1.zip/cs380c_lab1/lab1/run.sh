#!/usr/bin/env bash

# Script to run your translator.
./converter/src/converter