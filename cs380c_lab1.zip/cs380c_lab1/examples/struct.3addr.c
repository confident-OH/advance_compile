#include <stdio.h>
#include <stdint.h>
uint64_t global_array[4096], global_array_base=(uint64_t)global_array;
void main();
	
	
void main(){
	uint64_t local_array[72], local_array_base = (uint64_t)(local_array+9);
	uint64_t i;
	uint64_t r116;
	uint64_t r113;
	uint64_t r110;
	uint64_t r104;
	uint64_t r98;
	uint64_t r97;
	uint64_t r96;
	uint64_t r95;
	uint64_t r94;
	uint64_t r92;
	uint64_t r91;
	uint64_t r90;
	uint64_t r89;
	uint64_t r88;
	uint64_t r86;
	uint64_t r85;
	uint64_t r82;
	uint64_t r81;
	uint64_t r80;
	uint64_t r78;
	uint64_t r77;
	uint64_t r76;
	uint64_t r74;
	uint64_t r73;
	uint64_t r72;
	uint64_t r71;
	uint64_t r70;
	uint64_t r69;
	uint64_t r68;
	uint64_t r67;
	uint64_t r66;
	uint64_t r65;
	uint64_t r64;
	uint64_t r63;
	uint64_t r62;
	uint64_t r61;
	uint64_t r33;
	uint64_t r30;
	uint64_t r26;
	uint64_t r25;
	uint64_t r23;
	uint64_t r22;
	uint64_t r21;
	uint64_t r20;
	uint64_t r31;
	uint64_t r105;
	uint64_t r8;
	uint64_t r55;
	uint64_t r6;
	uint64_t r53;
	uint64_t r114;
	uint64_t r17;
	uint64_t r32;
	uint64_t r106;
	uint64_t r9;
	uint64_t r56;
	uint64_t r27;
	uint64_t r101;
	uint64_t r4;
	uint64_t r51;
	uint64_t r15;
	uint64_t r28;
	uint64_t r102;
	uint64_t r5;
	uint64_t r52;
	uint64_t r108;
	uint64_t r11;
	uint64_t r58;
	uint64_t r109;
	uint64_t r12;
	uint64_t r59;
	uint64_t r14;
	uint64_t r115;
	uint64_t r18;
	uint64_t r34;
	uint64_t r35;
	uint64_t r36;
	uint64_t r38;
	uint64_t r39;
	uint64_t r40;
	uint64_t r41;
	uint64_t r42;
	uint64_t r43;
	uint64_t r44;
	uint64_t r46;
	uint64_t r47;
	uint64_t r48;
	uint64_t r49;
	uint64_t r50;
	uint64_t r54;
	uint64_t r57;
	r4=(-48+local_array_base);

	r5=(r4+16);

	r6=(r5+8);

	*((uint64_t*)r6)=987654321;

	r8=(32728+global_array_base);

	r9=(r8+0);

	*((uint64_t*)r9)=1;

	r11=(32728+global_array_base);

	r12=(r11+8);

	*((uint64_t*)r12)=2;

	r14=(-48+local_array_base);

	r15=(r14+0);

	*((uint64_t*)r15)=9;

	r17=(-48+local_array_base);

	r18=(r17+8);

	*((uint64_t*)r18)=0;

	r20=(0*40);

	r21=(32608+global_array_base);

	r22=(r21+r20);

	r23=(r22+0);

	*((uint64_t*)r23)=3;

	r25=(0*40);

	r26=(32608+global_array_base);

	r27=(r26+r25);

	r28=(r27+8);

	*((uint64_t*)r28)=4;

	r30=(32728+global_array_base);

	r31=(r30+0);

	r32=*((uint64_t*)r31);

	r33=(r32*40);

	r34=(32608+global_array_base);

	r35=(r34+r33);

	r36=(r35+0);

	*((uint64_t*)r36)=5;

	r38=(32728+global_array_base);

	r39=(r38+0);

	r40=*((uint64_t*)r39);

	r41=(r40*40);

	r42=(32608+global_array_base);

	r43=(r42+r41);

	r44=(r43+8);

	*((uint64_t*)r44)=6;

	r46=(32728+global_array_base);

	r47=(r46+0);

	r48=*((uint64_t*)r47);

	r49=(r48-1);

	r50=(r49*40);

	r51=(32608+global_array_base);

	r52=(r51+r50);

	r53=(r52+0);

	r54=*((uint64_t*)r53);

	r55=(r54-1);

	r56=(r55*40);

	r57=(32608+global_array_base);

	r58=(r57+r56);

	r59=(r58+0);

	*((uint64_t*)r59)=7;

	r61=(32728+global_array_base);

	r62=(r61+8);

	r63=*((uint64_t*)r62);

	r64=(r63-2);

	r65=(r64*40);

	r66=(32608+global_array_base);

	r67=(r66+r65);

	r68=(r67+0);

	r69=*((uint64_t*)r68);

	r70=(r69-1);

	r71=(r70*40);

	r72=(32608+global_array_base);

	r73=(r72+r71);

	r74=(r73+8);

	*((uint64_t*)r74)=8;

	r76=(32728+global_array_base);

	r77=(r76+0);

	r78=*((uint64_t*)r77);

	printf(" %lld", r78);

	r80=(32728+global_array_base);

	r81=(r80+8);

	r82=*((uint64_t*)r81);

	printf(" %lld", r82);

	printf("\n");

	r85=(i=0);

label_86:
	r86=(i<3);

	if(r86==0){goto label_104;}

	r88=(i*40);

	r89=(32608+global_array_base);

	r90=(r89+r88);

	r91=(r90+0);

	r92=*((uint64_t*)r91);

	printf(" %lld", r92);

	r94=(i*40);

	r95=(32608+global_array_base);

	r96=(r95+r94);

	r97=(r96+8);

	r98=*((uint64_t*)r97);

	printf(" %lld", r98);

	printf("\n");

	r101=(i+1);

	r102=(i=r101);

	goto label_86;

label_104:
	r104=(-48+local_array_base);

	r105=(r104+0);

	r106=*((uint64_t*)r105);

	printf(" %lld", r106);

	r108=(-48+local_array_base);

	r109=(r108+8);

	r110=*((uint64_t*)r109);

	printf(" %lld", r110);

	printf("\n");

	r113=(-48+local_array_base);

	r114=(r113+16);

	r115=(r114+8);

	r116=*((uint64_t*)r115);

	printf(" %lld", r116);

	printf("\n");

	return;
}


