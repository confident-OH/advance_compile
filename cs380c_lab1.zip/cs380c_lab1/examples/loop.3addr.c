#include <stdio.h>
#include <stdint.h>
uint64_t global_array[4096], global_array_base=(uint64_t)global_array;
void main();
	
	
void main(){
	uint64_t local_array[64], local_array_base = (uint64_t)(local_array+8);
	uint64_t f;
	uint64_t e;
	uint64_t d;
	uint64_t x;
	uint64_t c;
	uint64_t n;
	uint64_t b;
	uint64_t a;
	uint64_t r43;
	uint64_t r42;
	uint64_t r40;
	uint64_t r39;
	uint64_t r37;
	uint64_t r36;
	uint64_t r14;
	uint64_t r13;
	uint64_t r11;
	uint64_t r34;
	uint64_t r10;
	uint64_t r33;
	uint64_t r16;
	uint64_t r5;
	uint64_t r28;
	uint64_t r4;
	uint64_t r27;
	uint64_t r9;
	uint64_t r17;
	uint64_t r6;
	uint64_t r7;
	uint64_t r30;
	uint64_t r19;
	uint64_t r20;
	uint64_t r22;
	uint64_t r23;
	uint64_t r25;
	uint64_t r26;
	uint64_t r31;
	r4=(n=13);

	r5=(x=0);

	r6=(a=0);

label_7:
	r7=(a<n);

	if(r7==0){goto label_45;}

	r9=(b=0);

	r10=(x=0);

label_11:
	r11=(b<n);

	if(r11==0){goto label_42;}

	r13=(c=0);

label_14:
	r14=(c<n);

	if(r14==0){goto label_39;}

	r16=(d=0);

label_17:
	r17=(d<n);

	if(r17==0){goto label_36;}

	r19=(e=0);

label_20:
	r20=(e<n);

	if(r20==0){goto label_33;}

	r22=(f=0);

label_23:
	r23=(f<n);

	if(r23==0){goto label_30;}

	r25=(x+1);

	r26=(x=r25);

	r27=(f+1);

	r28=(f=r27);

	goto label_23;

label_30:
	r30=(e+1);

	r31=(e=r30);

	goto label_20;

label_33:
	r33=(d+1);

	r34=(d=r33);

	goto label_17;

label_36:
	r36=(c+1);

	r37=(c=r36);

	goto label_14;

label_39:
	r39=(b+1);

	r40=(b=r39);

	goto label_11;

label_42:
	r42=(a+1);

	r43=(a=r42);

	goto label_7;

label_45:
	printf(" %lld", x);

	printf("\n");

	return;
}


