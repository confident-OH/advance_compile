#!/usr/bin/env bash

# A script that invokes your compiler.
