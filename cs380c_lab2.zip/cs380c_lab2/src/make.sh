#!/usr/bin/env bash

gcc -ggdb3 cs?.c -o csc
